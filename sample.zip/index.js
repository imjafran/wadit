#! /usr/bin/env node
const CLI = require ("./Wad/CLI.js");
const cli = new CLI(); 
cli.Run()